TrueTypeFont: Republica Minor (Regular, Italic, Bold, Bold Italic, and 3D)
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Thank you for having a look. Padaloma was one of the last projects i worked on before i left typography for over a decade. This is a smooth and hard bodied font that just aches to be used
in titles and logos. It's broad strokes intertwine with rounded corners to produce a pleasing appearance in tight quarters. The complete version contains basic and extended latin,
full punctuation, kerning, Eastern European accents, Cyrillic characters, and Greek characters. Italic, bold, and 3D are included with purchase of end user license agreement (EULA) upon request. 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license.
If you've previously licensed Padaloma you're grandfathered into this version. Thank you! I also design custom fonts for businesses, logos, and many other things. If you'd like to 
leave me a donation you can use the same address via paypal. Your generosity will be most appreciated!


visit www.sharkshock.net for more and take a bite out of BORING design!

